<?php
include "db.php";

//user registration
if (isset($_POST['adduser'])) {
    $first = $_POST['fname'];
    $last = $_POST['lname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $contact = $_POST['contact'];

    $date = date('Y-m-d');

    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($subscription) || empty($contact)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: users.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: users.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: users.php');
            exit;
        }

        //existing email address in our database
        $sql = "SELECT user_id FROM user WHERE email = '$email' LIMIT 1";
        $check_query = mysqli_query($con, $sql);
        $count_email = mysqli_num_rows($check_query);
        if ($count_email > 0) {
            $_SESSION['error'] = 'Email already exists';
            header('location:users.php');

        } else {

            $sql = "INSERT INTO `user` 
		(`user_id`, `fname`, `lname`, `email`, 
		`password`,`contact`,`joined_on`) 
		VALUES (NULL, '$first', '$last', '$email', 
		'$password','$contact','$date')";
            $run_query = mysqli_query($con, $sql);

            if ($run_query) {
                $_SESSION['success'] = 'User has been registered successfully';
                header('location:login.php');
            }
            else{
                $_SESSION['error'] = 'User has not been registered successfully';
                header('location:signup.php');
            }

        }
    }
}

//user login
if (isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM user WHERE email = '$email'AND password = '$password'";
    $run_query = mysqli_query($con,$sql);
    $count = mysqli_num_rows($run_query);
    $row = mysqli_fetch_array($run_query);
    $_SESSION["uid"] = $row["user_id"];
    $_SESSION["name"] = $row["fname"];

    if(empty($email) || empty($password)){
        $_SESSION['error'] = 'Fill in the form first';
        header('location:login.php');
    }
    else{
        if ($count == 1){
            echo 'login_success';
            header('location: index.php');
        }
        else{
            $_SESSION['error'] = 'Incorrect login credentials';
            header('location:login.php');
        }
    }
}

//logout
if (isset($_POST['logout'])){
    unset($_SESSION['uid']);
    unset($_SESSION['name']);

    header('location:login.php');
}

//betslip
if (isset($_POST['bet'])){
    $match=$_POST['match'];
    $user = $_POST['user'];
    $market = $_POST['market'];
    $pick = $_POST['pick'];

    //existing match
    $sql = "SELECT bet_id FROM betslip WHERE match_id = '$match' AND user_id ='$user' LIMIT 1";
    $check_query = mysqli_query($con, $sql);
    $count_ = mysqli_num_rows($check_query);
    $rw = mysqli_fetch_array($check_query);
    $bet=$rw['bet_id'];
    if ($count_ > 0) {
        $query = "UPDATE betslip SET `market`= '$pick' WHERE bet_id ='$bet'";
        $q = mysqli_query($con,$query);
        if ($q){
            $_SESSION['success']='Betslip added successfully';
            header('location:index.php');
        }
        else{
            $_SESSION['error']='Betslip not added successfully';
            header('location:index.php');
        }

    }
    else{
        $sql = "INSERT INTO betslip (`bet_id`,`match_id`,`user_id`,`market_id`,`market`) VALUES(NULL,'$match','$user','$market','$pick') ";
        $query = mysqli_query($con,$sql);

        if ($query){
            $_SESSION['success']='Betslip added successfully';
            header('location:index.php');
        }
        else{
            $_SESSION['error']='Betslip not added successfully';
            header('location:index.php');
        }
    }

}
//delete single bet
if (isset($_POST['delbet'])){
    $id = $_POST['bet'];
    $user=$_POST['user'];
    $sql= "DELETE FROM betslip WHERE bet_id = '$id'";

    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Game market deleted successfully';
        header('location:index.php');
    }
    else{
        $_SESSION['error']='Game market not deleted successfully';
        header('location:index.php');
    }
}
//delete betslip
if (isset($_POST['delbetslip'])){
    $user=$_POST['user'];
    $sql= "DELETE FROM betslip WHERE user_id = '$user'";

    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Game market deleted successfully';
        header('location:index.php');
    }
    else{
        $_SESSION['error']='Game market not deleted successfully';
        header('location:index.php');
    }
}