<?php
include "db.php";
include 'includes/header.php';
include 'includes/nav.php';
?>

    <!-- body -->

     <!--right-->
    <div class="container b_x">
        <div class="row">
            <div class="side-right">
                <ul>
                    <h5 class="headings">Top Leagues</h5>
                    <?php
                    $user=1;
                    $sql = "SELECT * FROM league";
                    $query = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($query)){
                        $league=$row['league_name'];
                        ?>
                        <li><?php echo $league?></li>
                        <?php
                    }
                    ?>
                </ul>
                <ul>
                    <h4 class="headings">Sports</h4>
                    <?php
                    $sql = "SELECT * FROM sport";
                    $query = mysqli_query($con, $sql);
                    while($row = mysqli_fetch_array($query)){
                        $sport=$row['sport_name'];
                        ?>
                        <li><?php echo $sport?></li>
                        <?php
                    }
                    ?>
                </ul>
            </div>

            <!--main-->
            <div class="main">
                <div class=" col-sm-12">
                    <div class="about_box">
                        <!-- ********** Hero Area Start ********** -->
                        <div class="hero-area">

                            <!-- Hero Slides Area -->
                            <div class="hero-slides owl-carousel">
                                <!-- Single Slide -->
                                <div class="single-hero-slide bg-img background-overlay" style="background-image: url(img/blog-img/keenan-constance-VTLcvV6UVaI-unsplash\ \(1\).jpg);"></div>
                                <!-- Single Slide -->
                                <div class="single-hero-slide bg-img background-overlay" style="background-image: url(img/blog-img/markus-spiske-gvGlAAIvIBg-unsplash.jpg);"></div>
                            </div>


                        </div>
                        <!-- ********** Hero Area End ********** -->
                        <!-- Hero Post Slide -->
                        <div class="hero-post-area">
                            <div class="container">
                                <div class="row">
                                    <div class="col-12">
                                        <div class="hero-post-slide">
                                            <?php
                                            $sql = "SELECT * FROM sport";
                                            $query = mysqli_query($con, $sql);
                                            while($row = mysqli_fetch_array($query)){
                                                $sport=$row['sport_name'];
                                                ?>
                                                <!-- Single Slide -->
                                                <div class="single-slide d-flex align-items-center">
                                                    <div class="post-number">
                                                        <p><i class="fa fa-futbol-o" aria-hidden="true"></i></p>
                                                    </div>
                                                    <div class="post-title">
                                                        <a href=""><?php echo $sport?></a>
                                                    </div>
                                                </div>
                                                <?php
                                            }
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <?php
                        $query = mysqli_query($con, "SELECT * FROM game") or die(mysqli_error());
                        while($fetch = mysqli_fetch_array($query)){

                        ?>
                        <div class="row d_flex">
                            <div class="col-md-5">
                                <div class="about_box_text">
                                    <div class="row">
                                        <div class="time"><i class="fa fa-clock-o" aria-hidden="true"></i> Today<br> 1200hrs</div>
                                        <?php
                                        $home= $fetch['home'];
                                        $sql = mysqli_query($con, "SELECT * FROM teams WHERE team_id='$home'");
                                        while ($row = mysqli_fetch_array($sql)) {
                                            $hm=$row['team_name'];
                                        }

                                        ?>
                                        <?php
                                        $away= $fetch['away'];
                                        $sql = mysqli_query($con, "SELECT * FROM teams WHERE team_id='$away'");
                                        while ($row = mysqli_fetch_array($sql)) {
                                            $aw = $row['team_name'];
                                        }
                                        ?>
                                        <h3><?php echo $hm?><br><?php echo  $aw?></h3>
                                    </div>
                                </div>
                            </div>
                            <?php
                            $id= $fetch['match_id'];
                            $sq = mysqli_query($con, "SELECT * FROM markets WHERE match_id='$id'");
                            while ($rw = mysqli_fetch_array($sq)) {
                                $market=$rw['market_id'];
                                $odh = $rw['home'];
                                $odd=$rw['draw'];
                                $oda=$rw['away'];
                                ?>
                                <div class=" col-md-7  pppp">
                                    <div class="about_box_img">
                                        <div class="row">
                                            <form action="action.php" method="post">
                                                <input type="hidden" value="<?php echo $id?>" name="match">
                                                <input type="hidden" value="1" name="user">
                                                <input type="hidden" value="<?php echo $market?>" name="market">
                                                <input type="hidden" value="<?php echo $odh?>" name="pick">
                                                <button type="submit" name="bet"><?php echo $hm?><br><?php echo $odh ?> </button>
                                            </form>
                                            <form action="action.php" method="post">
                                                <input type="hidden" value="<?php echo $id?>" name="match">
                                                <input type="hidden" value="1" name="user">
                                                <input type="hidden" value="<?php echo $market?>" name="market">
                                                <input type="hidden" value="<?php echo $odd?>" name="pick">
                                                <button type="submit" name="bet">X<br><?php echo $odd ?> </button>
                                            </form>
                                            <form action="action.php" method="post">
                                                <input type="hidden" value="<?php echo $id?>" name="match">
                                                <input type="hidden" value="1" name="user">
                                                <input type="hidden" value="<?php echo $market?>" name="market">
                                                <input type="hidden" value="<?php echo $oda?>" name="pick">
                                                <button type="submit" name="bet"><?php echo $aw?><br><?php echo $oda ?> </button>
                                            </form>
                                            <button>More<br>+150</button>
                                        </div>
                                    </div>
                                </div>
                                <?php
                            }
                            ?>

                            <hr>
                        </div>
                            <?php
                        }
                            ?>
                    </div>
                </div>
            </div>

            <!--left side-->
            <div class="side-left">
                <div class="heading">
                    <!-- Widget Area -->
                    <div class="sidebar-widget-area">
                        <h5 class="headings">Betslip</h5>
                        <div class="widget-content">
                            <?php
                            echo '
                            <div class="bet_card">
                            ';
                            ?>

                                <?php
                                $sql = "SELECT * FROM betslip";
                                $query = mysqli_query($con, $sql);
                                while($row = mysqli_fetch_array($query)){
                                    $bet=$row['bet_id'];
                                    $match=$row['match_id'];
                                    $user=$row['user_id'];
                                    $market=$row['market_id'];
                                    $pick=$row['market'];
                                    ?>
                                    <?php
                                    $sql = mysqli_query($con, "SELECT * FROM game WHERE match_id='$match'");
                                    while ($wr = mysqli_fetch_array($sql)) {
                                        ?>
                                        <?php
                                        $home= $wr['home'];
                                        $sql = mysqli_query($con, "SELECT * FROM teams WHERE team_id='$home'");
                                        while ($row = mysqli_fetch_array($sql)) {
                                            $hm=$row['team_name'];
                                        }

                                        ?>
                                        <?php
                                        $away= $wr['away'];
                                        $sql = mysqli_query($con, "SELECT * FROM teams WHERE team_id='$away'");
                                        while ($row = mysqli_fetch_array($sql)) {
                                            $aw = $row['team_name'];
                                        }
                                        ?>
                                        <p><h4><?php echo $hm ?> vs <?php echo$aw ?></h4>

                                        <?php
                                    }

                                    ?>
                                    <p><strong>Pick:</strong>
                                        <?php
                                        $sql = mysqli_query($con, "SELECT * FROM markets WHERE market_id='$market'");
                                        $row = mysqli_fetch_array($sql);
                                        $oh=$row['home'];
                                        $oa=$row['away'];
                                        $od=$row['draw'];
                                        if ($pick==$oh){
                                            echo "Home @ $pick ";
                                        }
                                        if ($pick==$oa){
                                            echo "Away @ $pick ";
                                        }
                                        if ($pick==$od){
                                            echo "Draw @ $pick "
                                            ;
                                        }
                                        ?>
                                    <div class="times">
                                        <form action="action.php" method="post">
                                            <input type="hidden"  name="match" value="<?php echo $match?>">
                                            <input type="hidden"  name="bet" value="<?php echo $bet?>">
                                            <input type="hidden"  name="user" value="<?php echo $user?>">
                                            <input type="submit"  name="delbet" value="X">
                                        </form>
                                    </div>
                                    </p><hr>

                                    <?php
                                }

                                $sql = "SELECT bet_id FROM betslip WHERE  user_id ='$user' LIMIT 1";
                                $check_query = mysqli_query($con, $sql);
                                $count_ = mysqli_num_rows($check_query);
                                if ($count_ > 0) {
                                  echo '
                                  <p><input type="number" placeholder="20"></p><hr>
                                <p>Number of bets<b class="right">1</b></p>
                                <p>Cost<b class="right">20</b></p>
                                <p>Total Return:<b class="right">20</b></p>
                                <button>Place bet</button>
                                <p class="clear">
                                    <form action="action.php" method="post">
                                    <input type="hidden" name="user" value="<?php echo $user?>">
                                    <button type="submit" name="delbetslip">Clear</button>
                                    </form>
                                    </p>
                                  ';

                                }

                                ?>
                            <?php
                            echo '
                            </div>
                            ';
                            ?>

                            <br>
                            <div class="social-area d-flex justify-content-between">
                                <a href="#"><i class="fa fa-facebook"></i></a>
                                <a href="#"><i class="fa fa-twitter"></i></a>
                                <a href="#"><i class="fa fa-pinterest"></i></a>
                                <a href="#"><i class="fa fa-vimeo"></i></a>
                                <a href="#"><i class="fa fa-instagram"></i></a>
                                <a href="#"><i class="fa fa-google"></i></a>
                            </div>
                        </div>
                    </div>
                    <!-- Widget Area -->
                </div>

            </div>
        </div>
    </div>



<?php
include "includes/footer.php";