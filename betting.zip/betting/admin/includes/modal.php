<!-- Add team-->
<div class="modal fade" id="addTeam">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add new team</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="POST" action="action.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="name" class="col-sm-3 control-label" >Team Name</label>

                        <div class="col-sm-5">
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>

                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                <button type="submit" class="btn btn-primary btn-flat" name="addTeam"><i class="fa fa-save"></i> Save</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Add sport-->
<div class="modal fade" id="addSport">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add new sport</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="POST" action="action.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="name" class="col-sm-3 control-label" >Sport Name</label>

                        <div class="col-sm-5">
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>

                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                <button type="submit" class="btn btn-primary btn-flat" name="addSport"><i class="fa fa-save"></i> Save</button>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Add league-->
<div class="modal fade" id="addLeague">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add new league</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="POST" action="action.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="name" class="col-sm-3 control-label" >League Name</label>

                        <div class="col-sm-5">
                            <input type="text" class="form-control" id="name" name="name" required>
                        </div>

                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                <button type="submit" class="btn btn-primary btn-flat" name="addLeague"><i class="fa fa-save"></i> Save</button>
                </form>
            </div>
        </div>
    </div>
</div>



<!-- Add user-->
<div class="modal fade" id="addUser">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add new user</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>

            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="POST" action="action.php" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="name" class="col-sm-3 control-label">First Name</label>

                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="name" name="firstname" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="name" class="col-sm-3 control-label">Last Name</label>

                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="name" name="lastname" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="email" class="col-sm-3 control-label">Email</label>

                        <div class="col-sm-9">
                            <input type="email" class="form-control" id="email" name="email" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="password" class="col-sm-3 control-label">Password</label>

                        <div class="col-sm-9">
                            <input type="password" class="form-control" id="password" name="password" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="repassword" class="col-sm-5 control-label">Confirm Password</label>

                        <div class="col-sm-9">
                            <input type="password" class="form-control" id="repassword" name="repassword" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="contact" class="col-sm-3 control-label">Contact</label>

                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="contact" name="contact" required>
                        </div>

                        <label for="league" class="col-sm-3 control-label">League</label>

                    </div>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                <button type="submit" class="btn btn-primary btn-flat" name="adduser"><i class="fa fa-save"></i> Save</button>
                </form>
            </div>
        </div>
    </div>
</div>

<!-- Add match-->
<div class="modal fade" id="newMatch">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add new match</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="POST" action="action.php" enctype="multipart/form-data">
                    <div class="form-group">

                        <label for="home" class="col-sm-3 control-label">Home Team</label>

                        <div class="col-sm-5">
                            <select class="form-control" id="home" name="home" required>
                                <?php
                                $result=mysqli_query($con,"select * from teams")or die ("query 1 incorrect.....");

                                while(list($id,$name)=mysqli_fetch_array($result))
                                {
                                    echo "
                                    <option value='$id'>$name</option>
                                   ";
                                }
                                ?>

                            </select>
                        </div>

                        <label for="away" class="col-sm-3 control-label">Away Team</label>

                        <div class="col-sm-5">
                            <select class="form-control" id="away" name="away" required>
                                <?php
                                $result=mysqli_query($con,"select * from teams")or die ("query 1 incorrect.....");

                                while(list($id,$name)=mysqli_fetch_array($result))
                                {
                                    echo "
                                    <option value='$id'>$name</option>
                                ";
                                }
                                ?>

                            </select>
                        </div>
                    </div>

                    <label for="league" class="col-sm-3 control-label">League</label>

                    <div class="col-sm-5">
                        <select class="form-control" id="league" name="league" required>
                            <?php
                            $result=mysqli_query($con,"select * from league")or die ("query 1 incorrect.....");

                            while(list($id,$name)=mysqli_fetch_array($result))
                            {
                                echo "
                                <option value='$id'>$name</option>
                            ";
                            }
                            ?>

                        </select>
                    </div>

                    <label for="league" class="col-sm-3 control-label">Sport</label>

                    <div class="col-sm-5">
                        <select class="form-control" id="sport" name="sport" required>
                            <?php
                            $result=mysqli_query($con,"select * from sport")or die ("query 1 incorrect.....");

                            while(list($id,$name)=mysqli_fetch_array($result))
                            {
                                echo "
                                <option value='$id'>$name</option>
                            ";
                            }
                            ?>

                        </select>
                    </div>
                   
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                <button type="submit" class="btn btn-primary btn-flat" name="addMatch"><i class="fa fa-save"></i> Save</button>
                </form>
            </div>
        </div>
    </div>
</div>


<!-- Add market-->
<div class="modal fade" id="addmarket">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Add new market</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="POST" action="action.php" enctype="multipart/form-data">
                    <div class="form-group">

                        <label for="match" class="col-sm-3 control-label">Match Id</label>

                        <div class="col-sm-5">
                            <select class="form-control" id="match" name="match" required>
                                <?php
                                $result=mysqli_query($con,"select * from game")or die ("query 1 incorrect.....");

                                while(list($id,$home,$away)=mysqli_fetch_array($result))
                                {
                                    $sql=mysqli_query($con,"select * from teams where team_id='$home'");
                                    $row = mysqli_fetch_array($sql); 
                                    $team1=$row['team_name'];

                                    $query=mysqli_query($con,"select * from teams where team_id='$away'");
                                    $fetch = mysqli_fetch_array($query); 
                                    $team2=$fetch['team_name'];

                                    echo "
                                    <option value='$id'>$team1 vs $team2</option>
                                   ";
                                }
                                ?>

                            </select>
                        </div>


                    </div>


                    <div class="form-group">
                        <label for="odds" class="col-sm-3 control-label">Home</label>

                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="home" name="home" required>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="odds" class="col-sm-3 control-label">Draw</label>

                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="draw" name="draw" required>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="odds" class="col-sm-3 control-label">Away</label>

                        <div class="col-sm-9">
                            <input type="text" class="form-control" id="away" name="away" required>
                        </div>
                    </div>
                   
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                <button type="submit" class="btn btn-primary btn-flat" name="addmarket"><i class="fa fa-save"></i> Save</button>
                </form>
            </div>
        </div>
    </div>
</div>

