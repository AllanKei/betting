<?php
session_start();
include 'db.php';
//add team
if (isset($_POST['addTeam'])){
    $name = $_POST['name'];

    $sql = "INSERT INTO teams (`team_id`, `team_name`) VALUES(NULL,'$name') ";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Team added successfully';
        header('location:team.php');
    }
    else{
        $_SESSION['error']='Team not added successfully';
        header('location:team.php');
    }
}
//edit team
if (isset($_POST['editteam'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $sql = "UPDATE teams SET `team_name`= '$name' WHERE team_id ='$id'";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Team updated successfully';
        header('location:team.php');
    }
    else{
        $_SESSION['error']='Team not updated successfully';
        header('location:team.php');
    }
}
//delete team
if (isset($_POST['delteam'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM teams WHERE team_id = '$id'";

    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Team deleted successfully';
        header('location:team.php');
    }
    else{
        $_SESSION['error']='Team not deleted successfully';
        header('location:team.php');
    }
}

//add sport
if (isset($_POST['addSport'])){
    $name = $_POST['name'];

    $sql = "INSERT INTO sport (`sport_id`, `sport_name`) VALUES(NULL,'$name') ";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Sport added successfully';
        header('location:sport.php');
    }
    else{
        $_SESSION['error']='Sport not added successfully';
        header('location:sport.php');
    }
}
//edit sport
if (isset($_POST['editsport'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $sql = "UPDATE sport SET `sport_name`= '$name' WHERE sport_id ='$id'";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Sport updated successfully';
        header('location:sport.php');
    }
    else{
        $_SESSION['error']='Sport not updated successfully';
        header('location:sport.php');
    }
}
//delete sport
if (isset($_POST['delsport'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM sport WHERE sport_id = '$id'";

    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Sport deleted successfully';
        header('location:sport.php');
    }
    else{
        $_SESSION['error']='Sport not deleted successfully';
        header('location:sport.php');
    }
}

//add league
if (isset($_POST['addLeague'])){
    $name = $_POST['name'];

    $sql = "INSERT INTO league (`league_id`, `league_name`) VALUES(NULL,'$name') ";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='League added successfully';
        header('location:league.php');
    }
    else{
        $_SESSION['error']='League not added successfully';
        header('location:league.php');
    }
}
//edit league
if (isset($_POST['editlea'])){
    $id = $_POST['id'];
    $name = $_POST['name'];
    $sql = "UPDATE league SET `league_name`= '$name' WHERE league_id ='$id'";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='League updated successfully';
        header('location:league.php');
    }
    else{
        $_SESSION['error']='League not updated successfully';
        header('location:league.php');
    }
}
//delete league
if (isset($_POST['dellea'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM league WHERE league_id = '$id'";

    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='League deleted successfully';
        header('location:league.php');
    }
    else{
        $_SESSION['error']='League not deleted successfully';
        header('location:league.php');
    }
}

//add markets
if (isset($_POST['addmarket'])){
    $match=$_POST['match'];
    $home = $_POST['home'];
    $draw = $_POST['draw'];
    $away = $_POST['away'];

    $sql = "INSERT INTO markets (`market_id`,`match_id`,`home`,`draw`,`away`) VALUES(NULL,'$match','$home','$draw','$away') ";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Match market added successfully';
        header('location:market.php');
    }
    else{
        $_SESSION['error']='Market not added successfully';
        header('location:market.php');
    }
}
//edit market
if (isset($_POST['editmarket'])){
    $id = $_POST['id'];
    $match=$_POST['match'];
    $home = $_POST['home'];
    $draw = $_POST['draw'];
    $away = $_POST['away'];

    $sql = "UPDATE markets SET `match_id`= '$match', `home`='$home',`draw`='$draw',`away`='$away' WHERE market_id ='$id'";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Game market updated successfully';
        header('location:market.php');
    }
    else{
        $_SESSION['error']='Game market not updated successfully';
        header('location:market.php');
    }
}
//delete market
if (isset($_POST['delmarket'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM markets WHERE market_id = '$id'";

    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Game market deleted successfully';
        header('location:market.php');
    }
    else{
        $_SESSION['error']='Game market not deleted successfully';
        header('location:market.php');
    }
}

//add match
if (isset($_POST['addMatch'])){
    $home = $_POST['home'];
    $away = $_POST['away'];
    $league = $_POST['league'];
    $sport =$_POST['sport'];
    $date = date('Y-m-d');

    $sql = "INSERT INTO game (`match_id`, `home`,`away`,`league`,`sport`,`date`) VALUES(NULL,'$home','$away','$league','$sport','$date') ";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Match added successfully';
        header('location:match.php');
    }
    else{
        $_SESSION['error']='Match not added successfully';
        header('location:match.php');
    }
}
//edit match
if (isset($_POST['editmatch'])){
    $id = $_POST['id'];
    $home = $_POST['home'];
    $away= $_POST['away'];
    $league = $_POST['league'];
    $sport =$_POST['sport'];

    $sql = "UPDATE game SET `home`= '$home', `away`='$away', `league`='$league',`sport`='$sport' WHERE match_id ='$id'";
    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Match updated successfully';
        header('location:match.php');
    }
    else{
        $_SESSION['error']='Match not updated successfully';
        header('location:match.php');
    }
}
//delete match
if (isset($_POST['delmatch'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM game WHERE match_id = '$id'";

    $query = mysqli_query($con,$sql);

    if ($query){
        $_SESSION['success']='Match deleted successfully';
        header('location:match.php');
    }
    else{
        $_SESSION['error']='Match not deleted successfully';
        header('location:match.php');
    }
}


//register admin
if (isset($_POST['register'])) {
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $contact = $_POST['contact'];

    $date = date('Y-m-d');

    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($contact)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: signup.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: signup.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: signup.php');
            exit;
        }

        //existing email address in our database
        $sql = "SELECT admin_id FROM admin WHERE email = '$email' LIMIT 1";
        $check_query = mysqli_query($con, $sql);
        $count_email = mysqli_num_rows($check_query);
        if ($count_email > 0) {
            $_SESSION['error'] = 'Email already exists, <a href="login.php">login</a> instead';
            header('location:signup.php');

        } else {

            $sql = "INSERT INTO `admin` 
		(`admin_id`, `fname`, `lname`, `email`, 
		`password`,`contact`,`created_at`) 
		VALUES (NULL, '$first', '$last', '$email', 
		'$password','$contact','$date')";
            $run_query = mysqli_query($con, $sql);
            $_SESSION["uid"] = mysqli_insert_id($con);
            $_SESSION["name"] = $first;

            $ip_add = getenv("REMOTE_ADDR");
            if ($run_query) {

                header('location: login.php');
                exit;
            }
        }
    }
}
//edit admin
if (isset($_POST['editadmin'])) {
    $id = $_POST['id'];
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $contact = $_POST['contact'];


    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($contact)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: profile.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: profile.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: profile.php');
            exit;
        }
        $sql = "UPDATE admin SET `fname`= '$first',`lname` = '$last',`email` = '$email',`password` = '$password',`contact`='$contact' WHERE admin_id = '$id' ";
        $run_query = mysqli_query($con, $sql);
        if ($run_query) {
            $_SESSION['success'] = 'Profile updated successfully';
            header('location:profile.php');
        } else {
            $_SESSION['error'] = 'Profile not updated successfully';
            header('location:profile.php');
        }
    }
}

//admin login
if (isset($_POST['login'])){
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM admin WHERE email = '$email'AND password = '$password'";
    $run_query = mysqli_query($con,$sql);
    $count = mysqli_num_rows($run_query);
    $row = mysqli_fetch_array($run_query);
    $_SESSION["uid"] = $row["admin_id"];
    $_SESSION["name"] = $row["fname"];

    if(empty($email) || empty($password)){
        $_SESSION['error'] = 'Fill in the form first';
        header('location:login.php');
    }
    else{
        if ($count == 1){
            echo 'login_success';
            header('location: index.php');
        }
        else{
            $_SESSION['error'] = 'Incorrect login credentials';
            header('location:login.php');
        }
    }
}
//logout
if (isset($_POST['logout'])){
    unset($_SESSION['uid']);
    unset($_SESSION['name']);

    header('location:login.php');
}


//add user
if (isset($_POST['adduser'])) {
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $subscription = $_POST['subscription'];
    $contact = $_POST['contact'];

    $date = date('Y-m-d');

    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($subscription) || empty($contact)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: users.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: users.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: users.php');
            exit;
        }

        //existing email address in our database
        $sql = "SELECT user_id FROM users WHERE email = '$email' LIMIT 1";
        $check_query = mysqli_query($con, $sql);
        $count_email = mysqli_num_rows($check_query);
        if ($count_email > 0) {
            $_SESSION['error'] = 'Email already exists';
            header('location:users.php');

        } else {

            $sql = "INSERT INTO `users` 
		(`user_id`, `fname`, `lname`, `email`, 
		`password`,`subscription`,`contact`,`created_on`) 
		VALUES (NULL, '$first', '$last', '$email', 
		'$password','$subscription','$contact','$date')";
            $run_query = mysqli_query($con, $sql);

            if ($run_query) {
                $_SESSION['success'] = 'User has been registered successfully';
                header('location:users.php');
            }
            else{
                $_SESSION['error'] = 'User has not been registered successfully';
                header('location:users.php');
            }
            
        }
    }
}
// edit user
if (isset($_POST['edituser'])) {
    $id = $_POST['id'];
    $first = $_POST['firstname'];
    $last = $_POST['lastname'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $repassword = $_POST['repassword'];
    $subscription = $_POST['subscription'];
    $contact = $_POST['contact'];

    $date = date('Y-m-d');

    if (empty($first) || empty($last) || empty($email) || empty($password) || empty($repassword) || empty($subscription) || empty($contact)) {
        $_SESSION['error'] = 'Please fill in the form';
        header('location: users.php');

    } else {
        if (strlen($password) < 8) {
            $_SESSION['error'] = 'Password is weak';
            header('location: users.php');
            exit;
        }
        if ($password != $repassword) {
            $_SESSION['error'] = 'Passwords dont match';
            header('location: users.php');
            exit;
        }
        else {

            $sql = "UPDATE users SET `fname`= '$first',`lname` = '$last',`email` = '$email',`password` = '$password',`subscription`='$subscription',`contact`='$contact' WHERE user_id = '$id' ";

            $run_query = mysqli_query($con, $sql);

            if ($run_query) {
                $_SESSION['success'] = 'User has been updated successfully';
                header('location:users.php');
            }
            else{
                $_SESSION['error'] = 'User has not been updated successfully';
                header('location:users.php');
            }
        }
    }
}
//delete user
if (isset($_POST['deluser'])){
    $id = $_POST['id'];

    $sql= "DELETE FROM users WHERE user_id = '$id'";
    $query = mysqli_query($con,$sql);
    if ($query){
        $_SESSION['success'] = "User deleted successfully";
        header('location:users.php');
    }
    else{
        $_SESSION['error'] = 'User not deleted';
        header('location:users.php');
    }
}
