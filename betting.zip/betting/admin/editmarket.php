<!-- Edit market-->
<div class="modal fade" id="editmarket<?php echo $fetch['market_id']?>">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Edit Market</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span></button>
            </div>
            <div class="modal-body">
                <form class="form-horizontal" method="POST" action="action.php" enctype="multipart/form-data">
                    <div class="form-group">

                        <label for="match" class="col-sm-3 control-label">Match Id</label>

                        <div class="col-sm-5">
                            <input type="hidden" name="id" value="<?php echo $fetch ['market_id']?>">
                            <select class="form-control" id="match" name="match" required>
                                <option value="<?php echo $match ?>"><?php echo "$hm vs $aw" ?></option>
                                <?php
                                $result=mysqli_query($con,"select * from game")or die ("query 1 incorrect.....");

                                while(list($id,$h,$a)=mysqli_fetch_array($result))
                                {
                                    $sql=mysqli_query($con,"select * from teams where team_id='$h'");
                                    $row = mysqli_fetch_array($sql); 
                                    $team1=$row['team_name'];

                                    $run_query=mysqli_query($con,"select * from teams where team_id='$a'");
                                    $get = mysqli_fetch_array($run_query); 
                                    $team2=$get['team_name'];

                                    echo "
                                    <option value='$id'>$team1 vs $team2</option>
                                   ";
                                }
                                ?>

                            </select>
                        </div>
                        <div class="form-group">
                            <label for="odds" class="col-sm-3 control-label">Home</label>

                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="home" name="home" value="<?php echo $home ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="odds" class="col-sm-3 control-label">Draw</label>

                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="draw" name="draw" value="<?php echo $draw ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label for="odds" class="col-sm-3 control-label"></label>

                            <div class="col-sm-9">
                                <input type="text" class="form-control" id="away" name="away" value="<?php echo $away ?>">
                            </div>
                        </div>
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
                <button type="submit" class="btn btn-primary btn-flat" name="editmarket"><i class="fa fa-save"></i> Save</button>
                </form>
            </div>
        </div>
    </div>
</div>





<!-- Delete market-->
<div class="modal fade" id="deletemarket<?php echo $fetch['market_id']?>">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Delete market</h5>
                <button class="close" type="button" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">Do you want to delete?</div>
            <div class="modal-footer">
                <form action="action.php" method="post">
                    <input type="hidden" name="id" value="<?php echo $fetch ['market_id']?>">
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                    <button class="btn btn-danger" type="submit" name="delmarket">Delete</button>
                </form>

            </div>
        </div>
    </div>
</div>